<?php
namespace wcf\acp;
use wcf\data\option\OptionEditor;

OptionEditor::resetCache();
