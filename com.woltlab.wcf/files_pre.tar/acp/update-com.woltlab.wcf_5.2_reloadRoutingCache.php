<?php
namespace wcf\acp;
use wcf\system\cache\builder\RoutingCacheBuilder;

RoutingCacheBuilder::getInstance()->reset();
