<?php
/* DO NOT REMOVE THIS FILE! -- As strange as it looks, this is a necessary work-around */
